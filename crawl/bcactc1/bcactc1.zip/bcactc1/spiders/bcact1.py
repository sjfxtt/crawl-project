# -*- coding: utf-8 -*-
import scrapy

class Bcact1Spider(scrapy.Spider):
    name = 'bcact1'
    allowed_domains = ['bcactc.com']
    start_urls = ['http://www.bcactc.com/home/gcxx/now_zyzbgg.aspx']

    def parse(self, response):
        yield scrapy.Request(url=response.url, callback=self.detail_parse, dont_filter=True)
        # yield scrapy.Request(url=response.url, callback=self.detail_parse, dont_filter=True)
    def detail_parse(self, response):
        values = response.xpath('//*[@id="Form1"]/div[2]/div/text()').extract_first()
        values = values.split()
        v = values[-1].split()
        last_page = int(v[0][-1])
        this_page = int(v[0][-3])
        for detail_list in detail_list1s:
            next_url = 'http://www.bcactc.com/home/gcxx/zbjggs_show.aspx?gcbh=' + detail_list
            yield scrapy.Request(next_url, callback=self.inner_parse)
        for detail_list in detail_list2s:
            next_url = 'http://www.bcactc.com/home/gcxx/zbjggs_show.aspx?gcbh='+detail_list
            yield scrapy.Request(next_url,callback=self.inner_parse)
        if this_page < last_page:
            a = response.xpath('//*[@id="__VIEWSTATE"]/@value').extract_first()
            b = response.xpath('//*[@id="__VIEWSTATEGENERATOR"]/@value').extract_first()
            c = response.xpath('//*[@id="__EVENTVALIDATION"]/@value').extract_first()
            post_data = {
                "__EVENTTARGET": "PagerControl1$_ctl4",
                "__EVENTARGUMENT": "",
                "__LASTFOCUS": "",
                "__VIEWSTATE": a,
                "__VIEWSTATEGENERATOR": b,
                "__EVENTVALIDATION": c,
                "gcbh_Text_Box": "",
                "gcmc_TextBox": "",
                "PagerControl1:_ctl4": "{}".format(this_page+1),
            }
            yield scrapy.FormRequest(url=response.url, formdata= post_data,callback=self.detail_parse, dont_filter=True)
    def inner_parse(self, response):
        Number = response.xpath('//table[@class="hei_text"]//tr[2]/td[2]/text()').extract_first().split()[0]
        Unitname = response.xpath('//table[@class="hei_text"]//tr[3]/td[2]/text()').extract_first().split()[0]
        ProjectName = response.xpath('//table[@class="hei_text"]//tr[4]/td[2]/text()').extract_first().split()[0]
        Place = response.xpath('//table[@class="hei_text"]//tr[5]/td[2]/text()').extract_first().split()[0]
        WinningBidder = response.xpath('//table[@class="hei_text"]//tr[6]/td[2]/text()').extract_first().split()[0]
        WinningBidPrice = response.xpath('//table[@class="hei_text"]//tr[7]/td[2]/text()').extract_first().split()[0]
        PublicityStartTime = response.xpath('//table[@class="hei_text"]//tr[8]/td[2]/text()').extract_first().split()[0]
        item = {
                'Number':Number,
                'Unitname':Unitname,
                'ProjectName':ProjectName,
                'Place':Place,
                'WinningBidder':WinningBidder,
                'WinningBidPrice':WinningBidPrice,
                'PublicityStartTime':PublicityStartTime
                }
        yield item